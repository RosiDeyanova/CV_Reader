﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cv_melon1.Models
{
    public class IndexDTO
    {
        public string id { get; set; }
        public string fisrtName { get; set; }
        public string lastName { get; set; }
        public string workingPlaces { get; set; }
        public string studyinPlaces { get; set; }
        public string fileText { get; set; }
    }
}
